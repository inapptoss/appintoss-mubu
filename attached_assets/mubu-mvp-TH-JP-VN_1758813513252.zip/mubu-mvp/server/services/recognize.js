import vision from '@google-cloud/vision';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

function getVisionClient() {
  const b64 = process.env.GOOGLE_CREDENTIALS_BASE64;
  if (!b64) return null;
  const json = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
  return new vision.ImageAnnotatorClient({ credentials: json });
}

const CURRENCY_FROM_SYMBOL = [
  { sym: '฿', code: 'THB' },
  { sym: 'บาท', code: 'THB' },
  { sym: '¥', code: 'JPY' },
  { sym: '円', code: 'JPY' },
  { sym: '円(税込)', code: 'JPY' },
  { sym: '₫', code: 'VND' },
  { sym: 'đ', code: 'VND' },
  { sym: 'VND', code: 'VND' },
  { sym: '$', code: 'USD' },
  { sym: '₩', code: 'KRW' },
  { sym: '원', code: 'KRW' },
  { sym: '€', code: 'EUR' },
  { sym: '₱', code: 'PHP' }
];

function detectCurrency(text) {
  for (const { sym, code } of CURRENCY_FROM_SYMBOL) {
    if (text.includes(sym)) return code;
  }
  return null;
}

function extractNumericPrice(text) {
  // robust match: pick the largest reasonable integer (ignore punctuation)
  const cand = [...text.matchAll(/(?<![A-Za-z])([0-9]{1,3}(?:[.,\s][0-9]{3})+|[0-9]+)(?:[.,][0-9]{2})?/g)].map(m => m[0]);
  if (!cand.length) return null;
  const normalize = s => parseFloat(s.replace(/[^0-9]/g, ''));
  const nums = cand.map(c => ({ raw:c, val: normalize(c) })).filter(x => !Number.isNaN(x.val)).sort((a,b)=> b.val-a.val);
  return nums[0]?.val ?? null;
}

function guessLanguageHints(ocrLocaleFallback) {
  // Allow frontend to pass a hint via header later if needed; for now basic fallback
  const map = {
    TH: ['th','en'],
    JP: ['ja','en'],
    VN: ['vi','en']
  };
  return map[ocrLocaleFallback] || ['en'];
}

export async function recognizeFromImage(filePath, countryCodeHint = null) {
  const client = getVisionClient();
  if (!client) {
    return {
      productName: 'Sample Product',
      localPrice: 200,
      currency: 'THB',
      ocrText: '฿200 Nike T-shirt'
    };
  }

  const imageContext = countryCodeHint ? { languageHints: guessLanguageHints(countryCodeHint) } : undefined;

  const [textRes] = await client.textDetection({ image: { source: { filename: filePath }}, imageContext });
  const [labelRes] = await client.labelDetection(filePath);

  const ocrText = (textRes.fullTextAnnotation?.text || '').trim();
  const labels = (labelRes.labelAnnotations || []).map(l => l.description);

  let productName = labels.slice(0, 1)[0] || 'Unknown Item';
  const brandMatch = ocrText.match(/\b(Nike|Adidas|Uniqlo|GU|Apple|Samsung|Sony|Muji|Zara|H&M|Anello|Onitsuka|Asics|Casio|Nintendo|Canon|Nikon|Panasonic|Shiseido)\b/i);
  if (brandMatch) productName = `${brandMatch[0]} ${productName}`.trim();

  const currency = detectCurrency(ocrText) || null;
  const localPrice = extractNumericPrice(ocrText) ?? 0;

  try { fs.unlinkSync(path.resolve(filePath)); } catch {}

  return { productName, localPrice, currency, ocrText };
}