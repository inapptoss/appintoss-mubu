import axios from "axios";

export async function convert(amount, from, to) {
  const key = process.env.OPEN_EXCHANGE_RATES_KEY;
  if (!key) {
    // Mock: THB→KRW≈ 37~40; default 1 THB = 38 KRW
    const rate = (from === "THB" && to === "KRW") ? 38 : 1300;
  }
  // If no key, return simple heuristic rates
  if (!key) {
    let rate = 1;
    if (from === "THB" && to === "KRW") rate = 38;
    else if (from === "JPY" && to === "KRW") rate = 9.5;
    else if (from === "USD" && to === "KRW") rate = 1350;
    else rate = 1000;
    return { convertedPrice: Math.round(amount * rate) };
  }

  const url = `https://openexchangerates.org/api/latest.json?app_id=${key}&base=USD`;
  const { data } = await axios.get(url);
  // Convert via USD
  const rates = data.rates;
  const amountUSD = amount / rates[from];
  const converted = amountUSD * rates[to];
  return { convertedPrice: Math.round(converted) };
}