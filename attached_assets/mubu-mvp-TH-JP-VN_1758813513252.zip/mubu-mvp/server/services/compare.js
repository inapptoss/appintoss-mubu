import axios from "axios";

const cache = new Map(); // key: productName -> {ts, data}
const TTL = 1000 * 60 * 10; // 10분 캐시

export async function compareKR(productName) {
  const now = Date.now();
  const key = productName.trim().toLowerCase();
  const cached = cache.get(key);
  if (cached && now - cached.ts < TTL) return cached.data;

  const id = process.env.NAVER_CLIENT_ID;
  const secret = process.env.NAVER_CLIENT_SECRET;

  if (!id || !secret) {
    const data = {
      lowestPrice: 24900,
      source: "Mock(Naver)",
      url: "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(productName)
    };
    cache.set(key, { ts: now, data });
    return data;
  }

  const url = "https://openapi.naver.com/v1/search/shop.json?display=10&sort=asc&query=" + encodeURIComponent(productName);
  const { data } = await axios.get(url, {
    headers: { "X-Naver-Client-Id": id, "X-Naver-Client-Secret": secret }
  });

  const items = data.items || [];
  if (!items.length) {
    const out = {
      lowestPrice: null,
      source: "Naver",
      url: "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(productName)
    };
    cache.set(key, { ts: now, data: out });
    return out;
  }

  let min = Number.MAX_SAFE_INTEGER;
  let best = null;
  for (const it of items) {
    const price = parseInt(it.lprice, 10);
    if (!Number.isNaN(price) && price < min) { min = price; best = it; }
  }
  const out = (min === Number.MAX_SAFE_INTEGER)
    ? { lowestPrice: null, source: "Naver", url: "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(productName) }
    : { lowestPrice: min, source: "Naver", url: best?.link || "https://search.shopping.naver.com/search/all?query=" + encodeURIComponent(productName) };

  cache.set(key, { ts: now, data: out });
  return out;
}