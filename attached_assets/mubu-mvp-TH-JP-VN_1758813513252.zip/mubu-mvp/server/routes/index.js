import { Router } from "express";
import multer from "multer";
import { recognizeFromImage } from "../services/recognize.js";
import { convert } from "../services/exchange.js";
import { compareKR } from "../services/compare.js";

const router = Router();
const upload = multer({ dest: "uploads/" });

router.post("/recognize", upload.single("image"), async (req, res) => {
  try {
    const hint = req.query.country || null; // TH | JP | VN
    const result = await recognizeFromImage(req.file?.path, hint);
    return res.json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "recognize_failed" });
  }
});

router.get("/convert", async (req, res) => {
  try {
    const { amount, from, to } = req.query;
    const { convertedPrice } = await convert(parseFloat(amount), from, to);
    res.json({ convertedPrice });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "convert_failed" });
  }
});

router.get("/compare", async (req, res) => {
  try {
    const { productName } = req.query;
    const out = await compareKR(productName);
    res.json(out);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "compare_failed" });
  }
});

// In-memory demo store
const memory = [];

router.post("/save", async (req, res) => {
  try {
    const item = { ...req.body, ts: Date.now() };
    memory.push(item);
    res.json({ success: true });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "save_failed" });
  }
});

router.get("/stats", (_req, res) => {
  const total = memory.reduce((s, it) => s + (Number(it.savedAmount)||0), 0);
  res.json({ totalSavedKRW: Math.round(total), items: memory.slice(-50) });
});

export default router;