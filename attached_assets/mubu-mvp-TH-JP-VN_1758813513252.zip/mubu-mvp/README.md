# MUBU (Must Buy) – MVP (Replit-ready)

Full‑stack skeleton: **React (Vite) PWA** + **Node/Express**.

## Quick start (Replit)
1) Create a new Replit from this project (or upload the zip).
2) Open a shell and run:
```
cd server && npm install
cd ../client && npm install
```
3) In one shell tab: `cd server && npm run dev`
4) In another shell tab: `cd client && npm run dev`
- Frontend: http://localhost:5173
- Backend: http://localhost:3000

## Env setup
Copy `server/.env.example` to `server/.env` and fill keys when you have them.

```
OPEN_EXCHANGE_RATES_KEY=your_key
NAVER_CLIENT_ID=your_id
NAVER_CLIENT_SECRET=your_secret
```

> Until keys are provided, the backend returns **mock data** so you can build UI first.

## Structure
```
mubu-mvp/
├─ server/        # Express API (OCR/item recognition, FX, KR price compare, save logs)
├─ client/        # React (Vite) PWA
└─ shared/        # Shared utilities (e.g., business rules)
```

## API (dev)
- `POST /api/recognize` → { productName, localPrice, currency }
- `GET  /api/convert?amount=100&from=THB&to=KRW` → { convertedPrice }
- `GET  /api/compare?productName=...` → { lowestPrice, source, url }
- `POST /api/save` → { success: true }

## Notes
- Image recognition: replace mock in `server/services/recognize.js` with Google Vision.
- FX: replace `server/services/exchange.js` with Open Exchange Rates (or other).
- KR compare: wire `server/services/compare.js` to Naver Shopping/Coupang Partners.
- PWA manifest is included (basic) – adjust icons later.
---

## Replit Secrets (환경변수) 설정 가이드
Replit 좌측 **Secrets** (lock 아이콘)에서 아래 키들을 추가하세요:

- `GOOGLE_CREDENTIALS_BASE64` : Google 서비스계정 JSON을 base64로 인코딩한 값
- `OPEN_EXCHANGE_RATES_KEY` : Open Exchange Rates API Key
- `NAVER_CLIENT_ID` : 네이버 오픈API 클라이언트 ID
- `NAVER_CLIENT_SECRET` : 네이버 오픈API 시크릿

**Base64 만들기 (로컬)**:
```bash
base64 -w 0 your-service-account.json > creds.b64
# creds.b64 내용 전체를 GOOGLE_CREDENTIALS_BASE64 값에 붙여넣기
```

## 원클릭 실행
Replit에서 ▶️ Run 버튼만 누르면 `server`와 `client`가 동시에 Dev 모드로 실행됩니다.
- Backend: http://localhost:3000 (Replit 외부 포트는 자동 프록시)
- Frontend: http://localhost:5173

## Country presets (TH/JP/VN)
- Shared presets at `shared/presets.js` (currency, language hints, local marketplaces).
- Backend `/api/recognize?country=TH|JP|VN` uses language hints for OCR.
- Frontend auto-detects from `navigator.language` to choose default country/currency.
- Result card shows quick links to **local marketplaces** for manual cross-check.
