import React, { useState, useMemo } from 'react'
import axios from '../lib/api.js'

const CURRENCIES = [
  { code: 'THB', label: 'THB (Baht, 태국)' },
  { code: 'JPY', label: 'JPY (엔, 일본)' },
  { code: 'VND', label: 'VND (동, 베트남)' },
  { code: 'USD', label: 'USD (달러)' },
  { code: 'KRW', label: 'KRW (원, 한국)' },
  { code: 'EUR', label: 'EUR (유로)' },
];

function guessCountryFromLocale(){
  const l = navigator.language || 'en';
  if (l.startsWith('ja')) return 'JP';
  if (l.startsWith('th')) return 'TH';
  if (l.startsWith('vi')) return 'VN';
  return null;
}

function defaultCurrencyForCountry(cc){
  if (cc === 'TH') return 'THB';
  if (cc === 'JP') return 'JPY';
  if (cc === 'VN') return 'VND';
  return 'USD';
}

export default function CameraCapture({ onAnalyzed }){
  const [busy, setBusy] = useState(false)
  const [overrideCurrency, setOverrideCurrency] = useState('THB')
  const [needsCurrency, setNeedsCurrency] = useState(false)
  const countryHint = useMemo(()=>guessCountryFromLocale(), [])

  async function handleFile(e){
    const file = e.target.files?.[0]
    if(!file) return
    setBusy(true)
    try{
      const fd = new FormData()
      fd.append('image', file)
      const recog = await axios.post(`/recognize?country=${countryHint||''}`, fd)
      let { productName, localPrice, currency } = recog.data

      // 통화 미검출 시 사용자 선택 또는 로케일 기본값
      if(!currency){
        const def = defaultCurrencyForCountry(countryHint)
        setOverrideCurrency(def)
        setNeedsCurrency(true)
        currency = def
      }

      const conv = await axios.get('/convert', { params: { amount: localPrice, from: currency, to: 'KRW' } })
      const cmp = await axios.get('/compare', { params: { productName } })
      const localKRW = conv.data.convertedPrice
      const diff = cmp.data.lowestPrice ? (cmp.data.lowestPrice - localKRW) : 0
      onAnalyzed({
        productName, localPrice, currency,
        localKRW, koreanPrice: cmp.data.lowestPrice,
        source: cmp.data.source, sourceUrl: cmp.data.url,
        diffKRW: diff,
        countryHint: countryHint
      })
    }finally{
      setBusy(false)
    }
  }

  return (
    <div>
      <p><b>상품을 촬영/업로드</b>하면 자동으로 인식합니다.</p>
      <input type="file" accept="image/*" capture="environment" onChange={handleFile} disabled={busy} />
      {needsCurrency && (
        <div style={{marginTop:12}}>
          <label>통화를 선택하세요: </label>
          <select value={overrideCurrency} onChange={e=>setOverrideCurrency(e.target.value)}>
            {CURRENCIES.map(c => <option key={c.code} value={c.code}>{c.label}</option>)}
          </select>
          <small className="muted" style={{marginLeft:8}}>OCR에서 통화를 찾지 못한 경우 사용</small>
        </div>
      )}
    </div>
  )
}