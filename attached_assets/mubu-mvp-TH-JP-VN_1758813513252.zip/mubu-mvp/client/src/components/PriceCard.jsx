import React from 'react'
import axios from '../lib/api.js'
import { verdictMessage } from '../../../shared/messages.js'
import LocalLinks from './LocalLinks.jsx'

export default function PriceCard({ data, onSaved }){
  const v = verdictMessage(data.diffKRW)
  async function save(){
    await axios.post('/save', {
      productName: data.productName,
      localPrice: data.localPrice,
      koreanPrice: data.koreanPrice,
      savedAmount: Math.max(0, data.koreanPrice - data.localKRW)
    })
    onSaved(Math.max(0, data.koreanPrice - data.localKRW))
  }

  return (
    <div className="card">
      <h3>{data.productName}</h3>
      <div className="grid" style={{gridTemplateColumns:'repeat(2,1fr)'}}>
        <div>
          <div>현지 가격</div>
          <h2>{data.localPrice?.toLocaleString?.() ?? data.localPrice} {data.currency}</h2>
          <small className="muted">≈ {data.localKRW?.toLocaleString?.() ?? data.localKRW} KRW</small>
        </div>
        <div>
          <div>한국 최저가</div>
          <h2>{data.koreanPrice ? data.koreanPrice.toLocaleString()+'원' : '정보없음'}</h2>
          {data.sourceUrl && <a href={data.sourceUrl} target="_blank" rel="noreferrer">상세 보기</a>}
        </div>
      </div>
      <LocalLinks productName={data.productName} forceCountry={data.countryHint||null} />
      <div style={{marginTop:12}} className={"badge " + v.tag}>{v.text}</div>
      <div style={{marginTop:12}}>
        <button className="btn" onClick={save}>샀다 ✅</button>
      </div>
    </div>
  )
}