import React from 'react'
import { COUNTRY_PRESETS } from '../../../shared/presets.js'

function guessCountryFromLocale() {
  const l = navigator.language || 'en';
  if (l.startsWith('ja')) return 'JP';
  if (l.startsWith('th')) return 'TH';
  if (l.startsWith('vi')) return 'VN';
  return null;
}

export default function LocalLinks({ productName, forceCountry=null }){
  const cc = forceCountry || guessCountryFromLocale();
  if (!cc) return null;
  const preset = COUNTRY_PRESETS[cc];
  if (!preset) return null;
  return (
    <div style={{marginTop:8}}>
      <small className="muted">현지 마켓에서 더 찾아보기:</small>{' '}
      {preset.localSearch.map((p, i)=>(
        <a key={i} href={p.url(productName)} target="_blank" rel="noreferrer" style={{marginRight:8}}>{p.name}</a>
      ))}
    </div>
  )
}