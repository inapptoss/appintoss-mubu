
import React, { useState, useEffect } from 'react'
import CameraCapture from '../components/CameraCapture.jsx'
import PriceCard from '../components/PriceCard.jsx'
import Dashboard from './Dashboard.jsx'

const COUNTRY_OPTIONS = [
  { code: 'TH', label: 'Thailand (THB)' },
  { code: 'JP', label: 'Japan (JPY)' },
  { code: 'VN', label: 'Vietnam (VND)' },
];

export default function App(){
  const [result, setResult] = useState(null)
  const [stats, setStats] = useState({ totalSavedKRW: 0, items: [] })
  const [country, setCountry] = useState('TH')

  // naive geolocation → country hint (for demo, map by lat/lon ranges)
  useEffect(()=>{
    if(!navigator.geolocation) return;
    navigator.geolocation.getCurrentPosition(pos => {
      const { latitude: lat, longitude: lon } = pos.coords || {};
      // very rough boxes
      if(lat>5 && lat<25 && lon>97 && lon<106) setCountry('TH');       // Thailand-ish
      else if(lat>24 && lat<46 && lon>123 && lon<146) setCountry('JP'); // Japan-ish
      else if(lat>8 && lat<24 && lon>102 && lon<110) setCountry('VN');  // Vietnam-ish
    });
  },[]);

  return (
    <div className="container">
      <h1>MUBU <small className="muted">Must Buy</small></h1>
      <div className="card">
        <div style={{display:'flex', gap:12, alignItems:'center'}}>
          <label>Country:</label>
          <select value={country} onChange={e=>setCountry(e.target.value)}>
            {COUNTRY_OPTIONS.map(c => <option key={c.code} value={c.code}>{c.label}</option>)}
          </select>
          <small className="muted">자동 감지 실패 시 수동 선택</small>
        </div>
      </div>
      <div className="card">
        <CameraCapture onAnalyzed={setResult} countryCode={country} />
      </div>
      {result && <PriceCard data={result} onSaved={(s)=>{
        setStats(prev=>({ ...prev, totalSavedKRW: prev.totalSavedKRW + s }))
      }} />}
      <Dashboard stats={stats} />
    </div>
  )
}
