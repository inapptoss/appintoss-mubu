import React from 'react'

export default function Dashboard({ stats }){
  return (
    <div className="card">
      <h3>비행기값 벌기 챌린지 ✈️💸</h3>
      <p>누적 절약 금액: <b>{stats.totalSavedKRW.toLocaleString()}원</b></p>
      <small className="muted">※ 서버 메모리 데모. 실제 서비스는 사용자 계정/DB 저장으로 전환</small>
    </div>
  )
}