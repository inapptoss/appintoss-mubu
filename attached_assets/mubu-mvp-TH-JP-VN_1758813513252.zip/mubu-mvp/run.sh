#!/usr/bin/env bash
set -e
# Install deps if node_modules missing
if [ ! -d server/node_modules ]; then (cd server && npm install); fi
if [ ! -d client/node_modules ]; then (cd client && npm install); fi

# Start backend and frontend together
(cd server && npm run dev) &
SERVER_PID=$!
(cd client && npm run dev) &
CLIENT_PID=$!

echo "Server PID: $SERVER_PID"
echo "Client PID: $CLIENT_PID"
wait