export const COUNTRY_PRESETS = {
  TH: {
    name: "Thailand",
    currency: "THB",
    languageHints: ["th", "en"],
    brandHints: ["Nike","Adidas","Uniqlo","Apple","Samsung","Sony","Muji","Zara","H&M","Anello","Asics","Onitsuka","Casio"],
    localSearch: [
      { name: "Lazada TH", url: (q)=>`https://www.lazada.co.th/catalog/?q=${encodeURIComponent(q)}` },
      { name: "Shopee TH", url: (q)=>`https://shopee.co.th/search?keyword=${encodeURIComponent(q)}` },
      { name: "Power Buy", url: (q)=>`https://www.powerbuy.co.th/en/search?text=${encodeURIComponent(q)}` }
    ]
  },
  JP: {
    name: "Japan",
    currency: "JPY",
    languageHints: ["ja", "en"],
    brandHints: ["Uniqlo","GU","MUJI","Casio","Sony","Nintendo","Canon","Nikon","Panasonic","Shiseido","Anello","Onitsuka"],
    localSearch: [
      { name: "Amazon JP", url: (q)=>`https://www.amazon.co.jp/s?k=${encodeURIComponent(q)}` },
      { name: "Rakuten", url: (q)=>`https://search.rakuten.co.jp/search/mall/${encodeURIComponent(q)}/` },
      { name: "Yahoo!ショッピング", url: (q)=>`https://shopping.yahoo.co.jp/search?p=${encodeURIComponent(q)}` }
    ]
  },
  VN: {
    name: "Vietnam",
    currency: "VND",
    languageHints: ["vi", "en"],
    brandHints: ["Nike","Adidas","Owen","Coolmate","An Phuoc","Samsung","Oppo","Xiaomi","Sony"],
    localSearch: [
      { name: "Shopee VN", url: (q)=>`https://shopee.vn/search?keyword=${encodeURIComponent(q)}` },
      { name: "Lazada VN", url: (q)=>`https://www.lazada.vn/catalog/?q=${encodeURIComponent(q)}` },
      { name: "Tiki", url: (q)=>`https://tiki.vn/search?q=${encodeURIComponent(q)}` }
    ]
  }
};