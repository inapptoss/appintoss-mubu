/**
 * Country presets for MUBU MVP (TH/JP/VN)
 */
export const COUNTRY_PRESETS = {
  TH: {
    currency: "THB",
    brands: ["Nike","Adidas","Apple","Samsung","Sony","Uniqlo","Muji","Asics","Vans","Converse","Xiaomi","Panasonic","Casio","Dyson","Levi's"],
    priceSymbols: ["฿","THB"],
    stopwords: ["บาท","ราคา","ลด","โปร","ถูก","แท้","ศูนย์"],
  },
  JP: {
    currency: "JPY",
    brands: ["Nike","Adidas","Apple","Samsung","Sony","Panasonic","Canon","Nikon","Sharp","Uniqlo","Muji","Asics","Nintendo","Fujifilm","Casio","Seiko","Dyson"],
    priceSymbols: ["¥","円","JPY"],
    stopwords: ["円","税込","税別","価格","割引","ポイント","送料無料"],
  },
  VN: {
    currency: "VND",
    brands: ["Nike","Adidas","Apple","Samsung","Sony","Panasonic","Xiaomi","Oppo","Vingroup","VinFast","Anker","Dyson","Casio","Converse","Vans"],
    priceSymbols: ["₫","VND"],
    stopwords: ["đ","đồng","giảm","giá","khuyến","mãi","chính","hãng"],
  }
};

export function guessCountryFromCurrency(currency){
  if(currency==="THB") return "TH";
  if(currency==="JPY") return "JP";
  if(currency==="VND") return "VN";
  return null;
}

export function buildSearchQuery(productName, countryCode){
  const preset = COUNTRY_PRESETS[countryCode] || { stopwords: [] };
  let q = productName || "";
  // remove excessive spaces and common stopwords
  for(const w of preset.stopwords){
    const re = new RegExp(`\b${w}\b`, 'gi');
    q = q.replace(re, " ");
  }
  q = q.replace(/\s{2,}/g, " ").trim();
  return q;
}