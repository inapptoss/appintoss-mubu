export function verdictMessage(diffKRW) {
  if (diffKRW >= 10000) return { tag: "deal", text: "다쓸어담어!!! 🛒🔥" };
  if (diffKRW >= -3000 && diffKRW < 10000) return { tag: "meh", text: "굳이 이걸 여기서? 🤔" };
  return { tag: "focus", text: "여행에 충실해라... 🏖️" };
}