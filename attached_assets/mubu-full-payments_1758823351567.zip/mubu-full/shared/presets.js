export const COUNTRY_PRESETS = {
  TH: {
    name: "Thailand",
    currency: "THB",
    languageHints: ["th","en"],
    localSearch: [
      { name: "Lazada TH", url: (q)=>`https://www.lazada.co.th/catalog/?q=${encodeURIComponent(q)}` },
      { name: "Shopee TH", url: (q)=>`https://shopee.co.th/search?keyword=${encodeURIComponent(q)}` }
    ]
  },
  JP: {
    name: "Japan",
    currency: "JPY",
    languageHints: ["ja","en"],
    localSearch: [
      { name: "Amazon JP", url: (q)=>`https://www.amazon.co.jp/s?k=${encodeURIComponent(q)}` },
      { name: "Rakuten", url: (q)=>`https://search.rakuten.co.jp/search/mall/${encodeURIComponent(q)}/` }
    ]
  },
  VN: {
    name: "Vietnam",
    currency: "VND",
    languageHints: ["vi","en"],
    localSearch: [
      { name: "Shopee VN", url: (q)=>`https://shopee.vn/search?keyword=${encodeURIComponent(q)}` },
      { name: "Lazada VN", url: (q)=>`https://www.lazada.vn/catalog/?q=${encodeURIComponent(q)}` }
    ]
  }
};