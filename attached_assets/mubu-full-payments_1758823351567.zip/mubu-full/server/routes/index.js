import { Router } from "express";
import multer from "multer";
import { recognizeFromImage } from "../services/recognize.js";
import { convert } from "../services/exchange.js";
import { compareKR } from "../services/compare.js";
import { affiliateLink } from "../services/affiliates.js";

const router = Router();
const upload = multer({ dest: "uploads/" });

// Image recognition
router.post("/recognize", upload.single("image"), async (req, res) => {
  try {
    const result = await recognizeFromImage(req.file?.path);
    return res.json(result);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "recognize_failed" });
  }
});

// FX
router.get("/convert", async (req, res) => {
  try {
    const { amount, from, to } = req.query;
    const { convertedPrice } = await convert(parseFloat(amount), from, to);
    res.json({ convertedPrice });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "convert_failed" });
  }
});

// Naver compare
router.get("/compare", async (req, res) => {
  try {
    const { productName } = req.query;
    const out = await compareKR(productName);
    res.json(out);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: "compare_failed" });
  }
});

// Affiliate link resolver
router.get('/affiliatelink', async (req, res) => {
  try {
    const { url } = req.query;
    if (!url) return res.status(400).json({ error: 'missing_url' });
    const out = await affiliateLink(url);
    res.json({ url: out });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'affiliate_failed' });
  }
});

export default router;