// server/routes/pay.js
import { Router } from "express";
import { startStripePayment, startIamportPayment } from "../services/payments.js";

const router = Router();

// Stripe start
router.post("/stripe/start", async (req, res) => {
  try {
    const { amountKRW, currency = "KRW", userId = "anonymous" } = req.body || {};
    const out = await startStripePayment({ amountKRW, currency, userId });
    res.json(out);
  } catch (e) {
    console.error("stripe/start error", e?.message);
    res.status(500).json({ error: "stripe_failed" });
  }
});

// Iamport start (server-side prepare)
router.post("/iamport/start", async (req, res) => {
  try {
    const { amountKRW, merchantUid } = req.body || {};
    const out = await startIamportPayment({ amountKRW, merchantUid });
    res.json(out);
  } catch (e) {
    console.error("iamport/start error", e?.message);
    res.status(500).json({ error: "iamport_failed" });
  }
});

export default router;
