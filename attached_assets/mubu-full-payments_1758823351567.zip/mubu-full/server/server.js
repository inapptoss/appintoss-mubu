import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import api from "./routes/index.js";
import payRoutes from "./routes/pay.js";
import Stripe from "stripe";
import bodyParser from "body-parser";

dotenv.config();
const app = express();
app.use(cors());

// Stripe webhook must use raw body BEFORE express.json
if (process.env.STRIPE_WEBHOOK_SECRET && process.env.STRIPE_SECRET_KEY) {
  app.post(
    "/webhook/stripe",
    bodyParser.raw({ type: "application/json" }),
    (req, res) => {
      try {
        const sig = req.headers["stripe-signature"];
        const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
        const event = stripe.webhooks.constructEvent(
          req.body,
          sig,
          process.env.STRIPE_WEBHOOK_SECRET
        );
        if (event.type === "checkout.session.completed") {
          const session = event.data.object;
          console.log("Stripe checkout completed:", {
            id: session.id,
            amount_total: session.amount_total,
            currency: session.currency,
            userId: session.metadata?.userId,
          });
          // TODO: persist subscription/purchase in DB
        }
        return res.json({ received: true });
      } catch (err) {
        console.error("Stripe webhook error:", err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
      }
    }
  );
}

// After webhook route, enable JSON body parsing for the rest
app.use(express.json({ limit: "10mb" }));

app.use("/api", api);
app.use("/api/pay", payRoutes);

// simple in-memory click log (from affiliates)
const clickLog = [];
app.get('/go', (req, res) => {
  const to = req.query.to;
  if (!to) return res.status(400).send('missing to');
  try {
    clickLog.push({ ts: Date.now(), ua: req.headers['user-agent']||'', ip: req.ip, to });
    const url = new URL(decodeURIComponent(to));
    res.redirect(url.toString());
  } catch {
    res.status(400).send('invalid url');
  }
});

// debug endpoint (dev only)
app.get('/_debug/clicks', (req, res)=>{
  if (req.query.admin !== '1') return res.status(403).json({ error: "forbidden" });
  res.json({ clicks: clickLog.slice(-100) });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log("MUBU API running on", PORT));
