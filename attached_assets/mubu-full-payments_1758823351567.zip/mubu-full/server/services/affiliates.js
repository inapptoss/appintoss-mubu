import crypto from 'crypto';
import axios from 'axios';

export async function affiliateLink(originalUrl){
  try{
    const u = new URL(originalUrl);
    if(u.host.includes('coupang.com')){
      const access = process.env.COUPANG_PARTNERS_ACCESS_KEY;
      const secret = process.env.COUPANG_PARTNERS_SECRET_KEY;
      const subId = process.env.COUPANG_SUB_ID || 'mubu';
      if(access && secret){
        const path = '/v2/providers/affiliate_open_api/apis/openapi/v1/deeplink';
        const method = 'POST';
        const datetime = new Date().toISOString().replace('Z','+00:00');
        const msg = `${datetime}${method}${path}`;
        const signature = crypto.createHmac('sha256', secret).update(msg).digest('base64');
        const endpoint = 'https://api-gateway.coupang.com'+path;
        const payload = { coupangUrls: [originalUrl], subId };
        const headers = { 'Content-Type':'application/json;charset=UTF-8', 'Authorization': `CEA algorithm=HmacSHA256, access-key=${access}, signed-date=${datetime}, signature=${signature}` };
        const { data } = await axios.post(endpoint, payload, { headers });
        const link = data?.data?.[0]?.shortenUrl || data?.data?.[0]?.landingUrl;
        if(link) return link;
      }
    }
  }catch(e){
    console.error('affiliateLink error', e?.message);
  }
  return '/go?to=' + encodeURIComponent(originalUrl);
}