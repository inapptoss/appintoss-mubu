import vision from '@google-cloud/vision';
import fs from 'fs';
import path from 'path';

function getVisionClient() {
  const b64 = process.env.GOOGLE_CREDENTIALS_BASE64;
  if (!b64) return null;
  const json = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
  return new vision.ImageAnnotatorClient({ credentials: json });
}

const SYMBOLS = [
  { s:'฿', c:'THB' }, { s:'บาท', c:'THB' },
  { s:'¥', c:'JPY' }, { s:'円', c:'JPY' },
  { s:'₫', c:'VND' }, { s:'đ', c:'VND' }, { s:'VND', c:'VND' },
  { s:'$', c:'USD' }, { s:'₩', c:'KRW' }, { s:'원', c:'KRW' },
  { s:'€', c:'EUR' }
];

function detectCurrency(text){
  for(const {s,c} of SYMBOLS){ if(text.includes(s)) return c; }
  return null;
}

function extractPrice(text){
  const cand = [...text.matchAll(/(?<![A-Za-z])(\d{1,3}(?:[.,\s]\d{3})+|\d+)(?:[.,]\d{2})?/g)].map(m=>m[0]);
  if(!cand.length) return null;
  const norm = v => parseFloat(v.replace(/[^0-9]/g,''));
  const nums = cand.map(v=>({raw:v, val:norm(v)})).filter(x=>Number.isFinite(x.val)).sort((a,b)=>b.val-a.val);
  return nums[0]?.val ?? null;
}

export async function recognizeFromImage(filePath){
  const client = getVisionClient();
  if (!client) {
    return { productName:'Sample Product', localPrice:200, currency:'THB', ocrText:'฿200 Nike T-shirt' };
  }
  const [textRes] = await client.textDetection(filePath);
  const [labelRes] = await client.labelDetection(filePath);
  const ocrText = (textRes.fullTextAnnotation?.text||'').trim();
  const labels = (labelRes.labelAnnotations||[]).map(l=>l.description);

  let productName = labels[0] || 'Unknown Item';
  const brand = ocrText.match(/\b(Nike|Adidas|Uniqlo|GU|Apple|Samsung|Sony|Muji|Zara|H&M|Anello|Onitsuka|Asics|Casio|Nintendo|Canon|Nikon|Panasonic|Shiseido)\b/i);
  if(brand) productName = `${brand[0]} ${productName}`.trim();

  const currency = detectCurrency(ocrText);
  const localPrice = extractPrice(ocrText) ?? 0;

  try { fs.unlinkSync(path.resolve(filePath)); } catch {}
  return { productName, localPrice, currency, ocrText };
}