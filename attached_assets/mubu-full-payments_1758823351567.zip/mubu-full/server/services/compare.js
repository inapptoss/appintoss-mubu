import axios from "axios";

const cache = new Map();
const TTL = 1000*60*10; // 10m

export async function compareKR(productName){
  const now = Date.now();
  const key = productName.trim().toLowerCase();
  const cached = cache.get(key);
  if (cached && now - cached.ts < TTL) return cached.data;

  const id = process.env.NAVER_CLIENT_ID;
  const secret = process.env.NAVER_CLIENT_SECRET;

  const BAD = /(중고|리퍼|리퍼비시|전시품|스크래치|파손|빈티지|호환|케이스만|패키지없음|미개봉 아님)/i;

  function sanitize(items){
    let arr = (items||[]).filter(it => !BAD.test((it.title||'') + ' ' + (it.mallName||'')));
    arr = arr.map(it => ({ ...it, _price: parseInt(it.lprice,10)})).filter(it => Number.isFinite(it._price));
    if(!arr.length) return [];
    arr.sort((a,b)=>a._price-b._price);
    const n = arr.length, s = Math.floor(n*0.1), e = Math.ceil(n*0.9);
    return arr.slice(s,e);
  }

  if(!id || !secret){
    const data = { lowestPrice: 24900, source: "Mock(Naver)", url: "https://search.shopping.naver.com/search/all?query="+encodeURIComponent(productName) };
    cache.set(key,{ts:now,data});
    return data;
  }

  const url = "https://openapi.naver.com/v1/search/shop.json?display=20&sort=asc&query="+encodeURIComponent(productName);
  const { data } = await axios.get(url,{ headers:{ "X-Naver-Client-Id": id, "X-Naver-Client-Secret": secret }});
  const items = sanitize(data.items);
  if(!items.length){
    const out = { lowestPrice: null, source: "Naver", url: "https://search.shopping.naver.com/search/all?query="+encodeURIComponent(productName) };
    cache.set(key,{ts:now,data:out}); return out;
  }
  const best = items[0];
  const out = { lowestPrice: best._price, source:"Naver", url: best.link || "https://search.shopping.naver.com/search/all?query="+encodeURIComponent(productName) };
  cache.set(key,{ts:now,data:out});
  return out;
}