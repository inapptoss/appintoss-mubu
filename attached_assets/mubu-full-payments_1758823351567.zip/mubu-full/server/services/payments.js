// server/services/payments.js
import Stripe from "stripe";
import axios from "axios";

const stripe = process.env.STRIPE_SECRET_KEY
  ? new Stripe(process.env.STRIPE_SECRET_KEY)
  : null;

// Stripe Checkout session
export async function startStripePayment({ amountKRW, currency = "KRW", userId }) {
  if (!stripe) throw new Error("Stripe not configured");
  const session = await stripe.checkout.sessions.create({
    payment_method_types: ["card"],
    line_items: [
      {
        price_data: {
          currency: currency.toLowerCase(),
          product_data: { name: "MUBU Premium" },
          // KRW는 소수점 없음. Stripe는 KRW도 정수 단위(원)로 입력.
          unit_amount: amountKRW,
        },
        quantity: 1,
      },
    ],
    mode: "payment", // 정기결제는 "subscription"
    success_url: "https://example.com/success",
    cancel_url: "https://example.com/cancel",
    metadata: { userId },
  });
  return { url: session.url };
}

// Iamport access token
async function getIamportToken() {
  const { data } = await axios.post("https://api.iamport.kr/users/getToken", {
    imp_key: process.env.IMP_KEY,
    imp_secret: process.env.IMP_SECRET,
  });
  if (!data?.response?.access_token) throw new Error("Iamport token failed");
  return data.response.access_token;
}

// Iamport prepare (server-side amount guard)
export async function startIamportPayment({ amountKRW, merchantUid }) {
  const token = await getIamportToken();
  const { data } = await axios.post(
    "https://api.iamport.kr/payments/prepare",
    { merchant_uid: merchantUid, amount: amountKRW },
    { headers: { Authorization: token } }
  );
  return data;
}
