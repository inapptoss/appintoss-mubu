import axios from 'axios';

let cache = { ts: 0, rates: null };

export async function convert(amount, from, to){
  const key = process.env.OPEN_EXCHANGE_RATES_KEY;
  if(!key){
    const mock = { THB:38, JPY:9.5, USD:1350, KRW:1, VND:0.055 };
    const rate = (mock[from] && to==='KRW') ? mock[from] : 1000;
    return { convertedPrice: Math.round(amount * rate) };
  }
  const now = Date.now();
  if(!cache.rates || now - cache.ts > 1000*60*15){
    const { data } = await axios.get(`https://openexchangerates.org/api/latest.json?app_id=${key}`);
    cache = { ts: now, rates: data.rates };
  }
  const r = cache.rates;
  const usd = amount / r[from];
  const out = usd * r[to];
  return { convertedPrice: Math.round(out) };
}