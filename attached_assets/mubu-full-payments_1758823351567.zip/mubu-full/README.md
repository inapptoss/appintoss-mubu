# MUBU (Must Buy) – MVP (Replit-ready, Affiliates + Upsell + Logs)

One-click dev: **React (Vite) PWA** + **Node/Express**.

## Run on Replit
- Upload this ZIP as a new Repl.
- Secrets(🔐) to set:
  - GOOGLE_CREDENTIALS_BASE64 (optional)
  - OPEN_EXCHANGE_RATES_KEY (optional)
  - NAVER_CLIENT_ID (recommended)
  - NAVER_CLIENT_SECRET (recommended)
  - COUPANG_PARTNERS_ACCESS_KEY (optional)
  - COUPANG_PARTNERS_SECRET_KEY (optional)
  - COUPANG_SUB_ID (optional, default mubu)
- Click ▶️ Run (starts server:3000 & client:5173)

## Client Env
- Set `VITE_CAMPAIGN_END=2025-12-31` to switch campaign banner off after date.
## Payments
### Secrets
- Stripe: `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET`
- Iamport: `IMP_KEY`, `IMP_SECRET`

### API
- `POST /api/pay/stripe/start` → `{ amountKRW: number, currency?: "KRW"|"USD"|..., userId?: string }` → `{ url }`
- `POST /api/pay/iamport/start` → `{ amountKRW: number, merchantUid: string }` → Iamport prepare response
- `POST /webhook/stripe` (Stripe Webhook, raw body)

> 클라이언트에서 Stripe는 `url`로 이동, 아임포트는 준비 완료 후 `IMP.request_pay()`를 호출하세요.
